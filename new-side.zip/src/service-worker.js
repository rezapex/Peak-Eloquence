// Service workers are not yet supported in StackBlitz
// This file is kept as a placeholder for future implementation