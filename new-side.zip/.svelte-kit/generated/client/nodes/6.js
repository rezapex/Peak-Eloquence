import * as universal from "../../../../src/routes/surah/[id]/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/surah/[id]/+page.svelte";